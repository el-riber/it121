let firstName = "Elida";
let lastName = " Ribeiro de Souza";
let yearsOfStudy = 2;
let goal = "tranfer to a four-year university";